//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ClipboardDemo.rc
//
#define IDR_SRVR_INPLACE                4
#define IDR_SRVR_EMBEDDED               6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ClipboardDemoTYPE           130
#define IDD_DIALOG1                     310
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_RADIO3                      1002
#define ID_CANCEL_EDIT_SRVR             32769
#define ID_VIEW_DEMONSTRATIONMETHODDIALOG 32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
